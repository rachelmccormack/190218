package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;

public class RiskAwareEval extends EvaluationMetric {

	EvaluationMetric parent;
	final double ALPHA;
	
	
	public RiskAwareEval(EvaluationMetric _parent, double alpha)
	{
		super(_parent.largerIsBetter());
		parent = _parent;
		ALPHA = alpha;
	}
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		RankingSample rankingSample = (RankingSample)sample;
		
		double[] naturalOrder = new double[predictions.length];
		for(int q=0;q<rankingSample.numQueries;q++)
		{
			int begin = rankingSample.queryBoundaries[q];
			int numDocs = rankingSample.queryBoundaries[q + 1] - begin;
			int nextScore = numDocs;
			for(int d=begin;d<(begin+numDocs);d++)
			{
				naturalOrder[d] = nextScore--;
			}
		}
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		double T1 = 0, T2 = 0;
		
			
		final int queryLength = perQuery.length;
		double F_reward = 0.0d;
		double F_risk = 0.0d;
		for(int i=0;i<queryLength;i++)
		{
			 F_reward += Math.max(0, perQuery[i] - baselinePerQuery[i]);
			 F_risk += Math.max(0,  baselinePerQuery[i] - perQuery[i]);
			 T1 += baselinePerQuery[i];
			 T2 += perQuery[i];			 
		}
		T1 /= (double)queryLength;
		T2 /= (double)queryLength;
		
		System.out.println("baselinePerQuery=" + T1);
		System.out.println("perQuery=" + T2);
		
		F_reward /= (double) queryLength;
		F_risk /= (double) queryLength;
		return F_reward - (1 + ALPHA) * F_risk;
	}

}
