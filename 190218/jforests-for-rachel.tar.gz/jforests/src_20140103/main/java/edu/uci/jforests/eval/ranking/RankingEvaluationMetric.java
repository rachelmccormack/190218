package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.Sample;

public abstract class RankingEvaluationMetric extends EvaluationMetric {

	public RankingEvaluationMetric(boolean isLargerBetter) {
		super(isLargerBetter);
	}

	public abstract double[] measureByQuery(double[] predictions, Sample sample) throws Exception;
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		final double[] result = measureByQuery(predictions, sample);
		double rtr = 0;
		for (int i = 0; i < result.length; i++) {
			rtr += result[i];			
		}
		rtr /= (double)result.length;		
		return rtr;
	}

}
