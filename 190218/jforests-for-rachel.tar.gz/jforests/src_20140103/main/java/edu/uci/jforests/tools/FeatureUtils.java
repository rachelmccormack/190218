package edu.uci.jforests.tools;

import edu.uci.jforests.learning.trees.Ensemble;
import edu.uci.jforests.learning.trees.Tree;

public class FeatureUtils {

	public static double[] featureImportance(Ensemble e, int featureCount)
	{
		final double[] importances = new double[featureCount];
		int t=0;
		for(Tree tree : e.getTrees())
		{
			final double treeWeight = e.getWeightAt(t); 
			final double[] treeImportances = new double[featureCount];
			tree.calculateFeatureImportances(treeImportances);
			for(int f=0;f<featureCount;f++)
			{
				importances[f] += treeWeight * treeImportances[f];
			}
			t++;
		}
		for(int f=0;f<featureCount;f++)
		{
			importances[f] /= (double) t;
		}
		return importances;
	}
	
}
