package edu.uci.jforests.tools;

import edu.uci.jforests.learning.trees.Ensemble;
import edu.uci.jforests.learning.trees.Tree;
import edu.uci.jforests.util.ArraysUtil;
import edu.uci.jforests.util.MathUtil;

public class FeatureUtils {

	public static double[] zscoreFeatureImportance(Ensemble e, int featureCount)
	{
		double[] importances = featureImportance(e,featureCount);
		double mean = MathUtil.getAvg(importances);
		double std =  MathUtil.getStd(importances);
		for(int i=0;i<featureCount;i++)
		{
			importances[i] = (importances[i] - mean) / std;
		}
		return importances;
	}

	public static double[] normalisedFeatureImportance(Ensemble e, int featureCount)
	{
		double[] importances = featureImportance(e,featureCount);
		double max = ArraysUtil.getMax(importances);
		for(int i=0;i<featureCount;i++)
		{
			importances[i] = 100.0d * importances[i] / max;
		}
		return importances;
	}
	
	public static double[] featureImportance(Ensemble e, int featureCount)
	{
		final double[] importances = new double[featureCount];
		int t=0;
		for(Tree tree : e.getTrees())
		{
			final double treeWeight = e.getWeightAt(t); 
			final double[] treeImportances = new double[featureCount];
			tree.calculateFeatureImportances(treeImportances);
			for(int f=0;f<featureCount;f++)
			{
				importances[f] += treeWeight * treeImportances[f];
			}
			t++;
		}
		for(int f=0;f<featureCount;f++)
		{
			importances[f] /= (double) t;
		}
		return importances;
	}
	
}
