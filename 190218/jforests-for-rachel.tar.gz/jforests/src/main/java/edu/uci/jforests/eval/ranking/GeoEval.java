package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.Sample;

public class GeoEval extends RankingEvaluationMetric {
	
	EvaluationMetric parent;
	final static double M_SMALLEST = 0.0001;
	

	public GeoEval(EvaluationMetric _parent)
	{
		super(_parent.largerIsBetter());
		assert _parent.largerIsBetter();
		parent = _parent;
	}
	
	static class GeoSwapScorer extends RankingEvaluationMetric.SwapScorer {
		
		final double[] maxDCG;
		final int[] labels;

		/** swapscorer of the parent metric */
		final SwapScorer parentSwap;
		
		double[] modelEval;
		
		GeoSwapScorer (double[] targets, int[] boundaries, int trunc, int[][] labelCounts, SwapScorer _parentSwap) throws Exception
		{
			super(targets, boundaries, trunc, labelCounts);
			maxDCG = NDCGEval.getMaxDCGForAllQueriesAtTruncation(targets, boundaries, trunc, labelCounts);
			this.labels = new int[targets.length];
			for(int i=0;i<targets.length;i++)
			{
				labels[i] = (int) targets[i];
			}
			assert NDCGEval.discounts != null;
			this.parentSwap = _parentSwap;
		}
		
		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			if (iteration == 0)
			{
				modelEval = new double[nDCG.length];				
			}
			else
			//if (iteration > 0)
			{
				modelEval = nDCG;
			}
		}
		
		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j)
		{			
			assert betterIdx < labels.length;
			assert worseIdx < labels.length;
			
			final double queryMaxDcg = maxDCG[queryIndex];
			
			
			double delta = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
			
			double deltaCheckNDCG = (NDCGEval.GAINS[labels[betterIdx]] - NDCGEval.GAINS[labels[worseIdx]])
							* ((NDCGEval.discounts[rank_j] - NDCGEval.discounts[rank_i])) / queryMaxDcg;
			
			assert delta == deltaCheckNDCG;
			
			double M_m = modelEval[queryIndex] < M_SMALLEST ? M_SMALLEST : modelEval[queryIndex];
			
			delta = Math.log(M_m + delta) - Math.log(M_m);  
			
			//double M_m = modelEval[queryIndex] < M_SMALLEST ? M_SMALLEST : modelEval[queryIndex];
			//delta = Math.log(M_m + delta) - Math.log(M_m); // i.e. percent change in per-query model effectiveness. 
			
			
			return delta;
		}
		
	}
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		double[] logndcgScores = measureByQuery(predictions, sample);
		
		double logSum = 0d;
		for (double logScore: logndcgScores) {
			logSum += logScore;
		}
		
		return Math.exp(logSum / (double) logndcgScores.length);
	}
	
	@Override
	public double[] measureByQuery(double[] predictions, Sample sample)
			throws Exception {
		
		double[] logndcgScores = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);

		double ndcgScore;
		for (int j = 0; j < logndcgScores.length; j++) {
			
			ndcgScore = logndcgScores[j] < M_SMALLEST ? M_SMALLEST : logndcgScores[j];
			
			logndcgScores[j] = Math.log(ndcgScore); 
		}
		
		return logndcgScores;
	}

	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception {
		final SwapScorer parentScorer = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new GeoSwapScorer(targets, boundaries, trunc, labelCounts, parentScorer);
	}


}
