/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package edu.uci.jforests.applications;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Properties;

import joptsimple.OptionParser;
import joptsimple.OptionSet;
import edu.uci.jforests.config.TrainingConfig;
import edu.uci.jforests.dataset.Dataset;
import edu.uci.jforests.learning.LearningUtils;
import edu.uci.jforests.learning.trees.Ensemble;
import edu.uci.jforests.learning.trees.decision.DecisionTree;
import edu.uci.jforests.learning.trees.regression.RegressionTree;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.tools.FeatureUtils;
import edu.uci.jforests.util.IOUtils;

/**
 * @author Yasser Ganjisaffar <ganjisaffar at gmail dot com>
 */

public class Runner {

	@SuppressWarnings("unchecked")
	private static void generateBin(ClassificationApp app, OptionSet options) throws Exception {
		if (!options.has("folder")) {
			System.err.println("The input folder is not specified.");
			return;
		}

		if (!options.has("file")) {
			System.err.println("Input files are not specified.");
			return;
		}

		String folder = (String) options.valueOf("folder");
		List<String> filesList = (List<String>) options.valuesOf("file");
		String[] files = new String[filesList.size()];
		for (int i = 0; i < files.length; i++) {
			files[i] = filesList.get(i);
		}

		System.out.println("Generating binary files...");
		app.getConvertor().convert(folder, files);
	}

	private static void train(ClassificationApp app, OptionSet options) throws Exception {
		if (!options.has("config-file")) {
			System.err.println("The configurations file is not specified.");
			return;
		}

		InputStream configInputStream = new FileInputStream((String) options.valueOf("config-file"));
		Properties configProperties = new Properties();
		configProperties.load(configInputStream);
		if (options.has("D")) {
			@SuppressWarnings("unchecked")
			List<String> props = (List<String>) options.valuesOf("D");
			for(String kv : props) {
				//System.err.println(kv);
				String[] KV = kv.split("=", 2);
				configProperties.put(KV[0], KV[1]);
				System.err.println("Added cmdline config option "+KV[0] + " => " + KV[1]);
			}
		}

		if (options.has("train-file")) {
			configProperties.put(TrainingConfig.TRAIN_FILENAME, options.valueOf("train-file"));
		}

		if (options.has("validation-file")) {
			configProperties.put(TrainingConfig.VALID_FILENAME, options.valueOf("validation-file"));
		}

		Ensemble ensemble;
		ensemble = app.run(configProperties);
	
		/*
		 * Dump the output model if requested.
		 */
		if (options.has("output-model")) {
			String outputModelFile = (String) options.valueOf("output-model");
			File file = new File(outputModelFile);
			PrintStream ensembleOutput = new PrintStream(file);
			ensembleOutput.println(ensemble);
			ensembleOutput.close();
		}

	}

	private static void predict(ClassificationApp app, OptionSet options) throws Exception {

		if (!options.has("model-file")) {
			System.err.println("Model file is not specified.");
			return;
		}

		if (!options.has("tree-type")) {
			System.err.println("Types of trees in the ensemble is not specified.");
			return;
		}

		if (!options.has("test-file")) {
			System.err.println("Test file is not specified.");
			return;
		}

		/*
		 * Load the ensemble
		 */
		File modelFile = new File((String) options.valueOf("model-file"));
		Ensemble ensemble = new Ensemble();
		if (options.valueOf("tree-type").equals("RegressionTree")) {
			ensemble.loadFromFile(RegressionTree.class, modelFile);
		} else if (options.valueOf("tree-type").equals("DecisionTree")) {
			ensemble.loadFromFile(DecisionTree.class, modelFile);
		} else {
			System.err.println("Unknown tree type: " + options.valueOf("tree-type"));
		}

		/*
		 * Load the data set
		 */
		InputStream in = new IOUtils().getInputStream((String) options.valueOf("test-file"));
		Dataset ds = app.newDataset();
		app.loadDataset(in, ds);
		Sample sample = app.createSample(ds, false);
		in.close();

		double[] predictions = new double[sample.size];
		int[] classes = new int[sample.size];
		final long startms = System.currentTimeMillis();
		final boolean decision = options.valueOf("tree-type").equals("DecisionTree");
		if (decision)
		{
			LearningUtils.getClassPredictions(sample, classes, ensemble);
		}
		else
		{
			LearningUtils.updateScores(sample, predictions, ensemble);
		}
		final long stopms = System.currentTimeMillis();
		System.err.println(sample.size + " predictions in "+ (stopms - startms) + " ms");

		PrintStream output = null;
		try{
			if (options.has("output-file")) {
				output = new PrintStream(new File((String) options.valueOf("output-file")));
			} else {
				output = System.out;
			}
			
			for (int i = 0; i < sample.size; i++) {
				if (decision)
					output.println(classes[i]);
				else
					output.println(predictions[i]);
			}
		}
		finally {
			output.close();
		}
	}
	
	private static void importance(OptionSet options) throws Exception {
		if (!options.has("model-file")) {
			System.err.println("Model file is not specified.");
			return;
		}

		if (!options.has("tree-type")) {
			System.err.println("Types of trees in the ensemble is not specified.");
			return;
		}

		/*
		 * Load the ensemble
		 */
		File modelFile = new File((String) options.valueOf("model-file"));
		Ensemble ensemble = new Ensemble();
		if (options.valueOf("tree-type").equals("RegressionTree")) {
			ensemble.loadFromFile(RegressionTree.class, modelFile);
		} else if (options.valueOf("tree-type").equals("DecisionTree")) {
			ensemble.loadFromFile(DecisionTree.class, modelFile);
		} else {
			System.err.println("Unknown tree type: " + options.valueOf("tree-type"));
		}
		
		int featureCount = 136;
		double[] importances = null;
		if (options.has("normalise")) {
			if (options.valueOf("normalise").equals("none"))
				importances = FeatureUtils.featureImportance(ensemble, featureCount);
			else if (options.valueOf("normalise").equals("100"))
				importances = FeatureUtils.normalisedFeatureImportance(ensemble, featureCount);
			else if (options.valueOf("normalise").equals("z") || options.valueOf("normalise").equals("zscore"))
				importances = FeatureUtils.zscoreFeatureImportance(ensemble, featureCount);
			else 
				System.err.println("Unknown normalisation: " + options.valueOf("normalise"));
		} else { 
			importances = FeatureUtils.normalisedFeatureImportance(ensemble, featureCount);
		}
		for(int i=0;i<featureCount;i++)
		{
			System.out.println(importances[i]);
		}
	}
	
	public static ClassificationApp getApp(OptionSet opts) throws Exception {
		if (opts.has("ranking"))
		{
			return new RankingApp();
		}
		else if (opts.hasArgument("app"))
		{
			String appClassName = (String) opts.valueOf("app");
			if (! appClassName.contains("."))
				appClassName = "edu.uci.jforests.applications.";
			ClassificationApp app = Class.forName(appClassName).asSubclass(ClassificationApp.class).newInstance();
			return app;
		}
		return new ClassificationApp();
	}

	public static void main(String[] args) throws Exception {

		OptionParser parser = new OptionParser();

		parser.accepts("cmd").withRequiredArg();
		
		parser.accepts("ranking");
		parser.accepts("app").withRequiredArg();

		/*
		 * Bin generation arguments
		 */
		parser.accepts("folder").withRequiredArg();
		parser.accepts("file").withRequiredArg();

		/*
		 * Training arguments
		 */
		//for configuration
		parser.accepts("config-file").withRequiredArg();
		parser.accepts("D").withRequiredArg();
		//others
		parser.accepts("train-file").withRequiredArg();
		parser.accepts("validation-file").withRequiredArg();
		parser.accepts("output-model").withRequiredArg();

		/*
		 * Prediction arguments
		 */
		parser.accepts("model-file").withRequiredArg();
		parser.accepts("tree-type").withRequiredArg();
		parser.accepts("test-file").withRequiredArg();
		parser.accepts("output-file").withRequiredArg();

		/*
		 * feature importance arguments
		 */
		parser.accepts("normalise").withRequiredArg();

		OptionSet options = parser.parse(args);

		if (!options.has("cmd")) {
			System.err.println("You must specify the command through 'cmd' parameter.");
			return;
		}
		
		ClassificationApp app = getApp(options);

		if (options.valueOf("cmd").equals("generate-bin")) {
			generateBin(app, options);
		} else if (options.valueOf("cmd").equals("train")) {
			train(app, options);
		} else if (options.valueOf("cmd").equals("predict")) {
			predict(app, options);
		} else if (options.valueOf("cmd").equals("feature-importance")) {
			importance(options);
		} else {
			System.err.println("Unknown command: " + options.valueOf("cmd"));
		}

		/*
		 * Make sure that thread pool is terminated.
		 */
		ClassificationApp.shutdown();
	}

	
}
