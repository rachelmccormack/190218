package edu.uci.jforests.eval.ranking;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.CDF_Normal;
import edu.uci.jforests.util.MathUtil;
import edu.uci.jforests.util.concurrency.BlockingThreadPoolExecutor;

public class GOFSAROEval extends URiskAwareEval {

	public GOFSAROEval(EvaluationMetric _parent, double alpha) {
		super(_parent, alpha);
	}

	class SAROSwapScorer extends URiskSwapScorer
	{
		double c;
		double baselineMean;
		
		
		public SAROSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
			c = ((double) boundaries.length -1);
		}
		
		@Override
		/* Basic Version */
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double M_m = modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex];
			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
	
			// Score difference
			double d_i = M_m - M_b;
			double pstd = M_m + M_b != 0D ? Math.sqrt(M_m + M_b) : 1D;
			final double PGOF = d_i / pstd;
			
			// beta asymptotically ranges in between a value as small as 0 and a value as large as alpha,
			// proportionally to the level of risk commited by the current topic.
			// This version follows the way how URisk weighs a given delta.
			//NB: in Dincer et al, beta is called \alpha'
			final double beta = (1 - CDF_Normal.normp(PGOF)) * alpha;

			final double delta_T;
			
			//Scenarios are as defined by Wang et al, SIGIR 2012.
			//Scenario A
			if (M_m <=  M_b)
			{
				//case A1
				if (rel_i > rel_j && rank_i < rank_j)
				{
					delta_T = (1.0d + beta) * delta_M;
				}
				//case A2
				else
				{	
					if (M_b > M_m + delta_M)
					{
						delta_T = (1.0d + beta) * delta_M;
					}
					else
					{
						delta_T = beta * (M_b - M_m) + delta_M;
					}					
				}
			}
			else //Scenario B
			{
				if( rel_i > rel_j && rank_i < rank_j )
				{
					//case B1
					if (M_b > M_m - Math.abs(delta_M))
					{
						delta_T = beta * (M_m - M_b) - (1 + beta) * Math.abs(delta_M);
					}
					else
					{
						delta_T = delta_M;
					}
				}
				else 
				{
					delta_T = delta_M;
				}
			}
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, delta_T);
			
			return delta_T;
		}

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			if (iteration == 0)
			{
				baselineMean = MathUtil.getAvg(baselineEval);
				System.err.println("Iteration 0 NDCG=" + Arrays.toString(nDCG));
			}
			else
			{
				System.err.println("Iteration " + iteration + " NDCG=" + Arrays.toString(nDCG));
			}
		}	
	}

	/** returns double[] params where params[0] = GOF */
	public static double[] getEstimates(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;
        double sum = 0D;
        double d_i = 0D;
        double qstd = 0D; // with-in-query std
        double pgof = 0D; // per-query goodness-of-fit
        
        for(int i=0; i < c; i++)
        {
        	qstd = perQuery[i] + baselinePerQuery[i] != 0D ? Math.sqrt(perQuery[i] + baselinePerQuery[i]) : 1D;
        	pgof = (perQuery[i] - baselinePerQuery[i]) / qstd;
            if (perQuery[i] > baselinePerQuery[i])
                d_i = pgof;
            else 
            {
            	double beta = (1 - CDF_Normal.normp(pgof)) * ALPHA;
                d_i = (1 + beta) * (pgof);
            }
            sum += d_i;
        }

        final double GOF = sum /c;
        return new double[] {GOF};
	}
	
	/* Returns GOF */
	public static double GOF_measure(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        double[] params = getEstimates(baselinePerQuery, perQuery, ALPHA);
		return params[0];   
	}
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		final RankingSample rankingSample = (RankingSample)sample;
		assert rankingSample.queryBoundaries.length -1 == rankingSample.numQueries;
		final double[] naturalOrder = computeNaturalOrderScores(predictions.length, rankingSample.queryBoundaries);
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		return GOF_measure(baselinePerQuery, perQuery, this.ALPHA);
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new SAROSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
	public static class TestTRiskSwaps 
	{
		@Test public void testTwoOrThreeQueries() throws Exception
		{
			BlockingThreadPoolExecutor.init(1);
			TRiskAwareSAROEval eval = new TRiskAwareSAROEval(new NDCGEval(2,  2), 1);
			SwapScorer s;
			
			s = eval.getSwapScorer(
					new double[]{0,1,0,1}, 
					new int[]{0,2,4}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1,0.2});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			s = eval.getSwapScorer(
					new double[]{0,1,0,1,0,1}, 
					new int[]{0,2,4,6}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1,0.2,0.1});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			
//			s = eval.getSwapScorer(
//					new double[]{0,1}, 
//					new int[]{0,2}, 
//					2, 
//					new int[][]{new int[]{1,1,0,0,0}});
//			s.setCurrentIterationEvaluation(0, new double[]{0.2});
//			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			assertTrue(true);
		}
	}
	
}
