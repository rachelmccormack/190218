package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.util.CDF_Normal;

public class GOFFAROEval extends GOFSAROEval {

	public GOFFAROEval(EvaluationMetric _parent, double alpha) {
		super(_parent, alpha);
	}

	
	class GFAROSwapScorer extends SAROSwapScorer
	{
		public GFAROSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}
		
		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double M_m = modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex];

			// Score difference
			double d_i = M_m - M_b;
			double pstd = M_m + M_b != 0D ? Math.sqrt(M_m + M_b) : 1D;
			final double PGOF = d_i / pstd;
			
			// beta asymptotically ranges in between a value as small as 0 and a value as large as alpha,
			// proportionally to the level of risk commited by the current topic.
			// This version follows its own way of weighing a given delta.
			// NB: in Dincer et al, beta is called \alpha'
			final double beta = (1 - CDF_Normal.normp(PGOF)) * alpha;

			final double delta_T = (1 + beta) * delta_M;
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, delta_T);
			
			return delta_T;
		}

		
	}

		
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new GFAROSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
}
