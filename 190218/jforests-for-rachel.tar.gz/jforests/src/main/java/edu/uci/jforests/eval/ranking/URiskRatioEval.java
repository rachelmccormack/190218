package edu.uci.jforests.eval.ranking;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.MathUtil;
import edu.uci.jforests.util.concurrency.BlockingThreadPoolExecutor;

@SuppressWarnings("restriction")
public class URiskRatioEval extends RankingEvaluationMetric {

	EvaluationMetric parent;
	final double ALPHA;
	final static double M_SMALLEST = 0.0001;
	
	static class URiskRatioSwapScorer extends SwapScorer
	{
		/** alpha value in the Utility measure */
		double alpha;
		/** swapscorer of the parent metric */
		SwapScorer parentSwap;
		/** M_m: the performance over all queries of the current model
		 * BEFORE any documents are swapped
		 */
		double[] modelEval;
		/** M_b: the mean performance of the baseline ranking over all queries. */
		double[] baselineEval;
			
		
		public URiskRatioSwapScorer(
				double[] targets, 
				int[] boundaries, 
				int trunc,
				int[][] labelCounts,
				double _alpha,
				SwapScorer _parent
				) 
		{
			super(targets, boundaries, trunc, labelCounts);
			this.alpha = _alpha;
			this.parentSwap = _parent;
		}

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			final double meanNDCG = MathUtil.getAvg(nDCG);
			if (iteration == 0)
			{
				System.err.println("Baseline in iteration 0 has peformance " + meanNDCG);
				baselineEval = nDCG;
				modelEval = new double[baselineEval.length];
			}
			else
			{
				System.err.println("Model in iteration "+iteration+" has peformance " + meanNDCG);
				modelEval = nDCG;
			}
			System.err.println("Iteration " + iteration + " NDCG=" + Arrays.toString(nDCG));
		}
		
		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i,
				int worseIdx, int rank_j) {
			
			final double M_m = modelEval[queryIndex] < M_SMALLEST ? M_SMALLEST : modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex] < M_SMALLEST ? M_SMALLEST : baselineEval[queryIndex];
			
			//change in effectiveness
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
			
//			final double rel_i = targets[betterIdx];
//			final double rel_j = targets[worseIdx];
			
			
			//Percentage change in tradeoff
			double delta_T = delta_M / M_b; // i.e. [ (M_m + delta_M) / M_b ] -  ( M_m / M_b ) 
			
			if ((M_m > M_b) || (M_m + delta_M > M_b))
				return delta_T;
			else
				return (1 + alpha) * delta_T;
		}
		
	}
	
	public URiskRatioEval(EvaluationMetric _parent, double alpha)
	{
		super(_parent.largerIsBetter());
		assert _parent.largerIsBetter();
		parent = _parent;
		ALPHA = alpha;
	}
		
	/**
	 * Calculates the arithmetic mean of the risk ratios delta=M_m/M_b.  
	 */
	@Override 
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		double[] URiskRatios = measureByQuery(predictions, sample);
		
		double sum = 0.0d;
		for(double uriskScore : URiskRatios)
			sum += uriskScore;
		
		final double c = URiskRatios.length;
		return sum / c;
	}

	/**
	 * Returns per-query risk-ratio delta=M_m/M_b;
	 */
	@Override
	public double[] measureByQuery(double[] predictions, Sample sample)
			throws Exception {

		double[] rtn = new double[predictions.length];

		final RankingSample rankingSample = (RankingSample)sample;
		assert rankingSample.queryBoundaries.length -1 == rankingSample.numQueries;
		final double[] naturalOrder = computeNaturalOrderScores(predictions.length, rankingSample.queryBoundaries);
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		
		final int queryLength = baselinePerQuery.length;
		
		double M_m; 
		double M_b;
		double percentChange;

		for(int i=0; i < queryLength; i++)
		{
			M_b = baselinePerQuery[i] < M_SMALLEST ? M_SMALLEST : baselinePerQuery[i];
			M_m = perQuery[i] < M_SMALLEST ? M_SMALLEST : perQuery[i];
			
			percentChange = M_m/M_b;
			if (M_m > M_b ) // Reward
				rtn[i] = percentChange;
			else // Risk
				rtn[i] = -1.0 * (1 + ALPHA) * percentChange;
		}
		
		return rtn;
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentModel = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new URiskRatioSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentModel);
	}

	@Override
	public EvaluationMetric getParentMetric() {
		return ((RankingEvaluationMetric) parent).getParentMetric();
	}

	public static class TestURiskRatioSwaps 
	{
		@Test public void testTwoQueries() throws Exception
		{
			BlockingThreadPoolExecutor.init(1);
			RankingEvaluationMetric eval = new URiskAwareEval(new NDCGEval(2,  2), 1);
			SwapScorer s = eval.getSwapScorer(
					new double[]{0,1,0,1}, 
					new int[]{0,2,4}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1,0.2});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			s = eval.getSwapScorer(
					new double[]{0,1}, 
					new int[]{0,2}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			assertTrue(true);
		}
	}


}
