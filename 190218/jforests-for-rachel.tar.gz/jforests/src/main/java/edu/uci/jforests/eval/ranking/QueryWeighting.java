package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.Sample;

/** An evaluation metric that weights different queries differently.
 * @author craigm
 */
public class QueryWeighting extends RankingEvaluationMetric {

	double[] queryWeights;
	RankingEvaluationMetric parent;
	
	class QueryWeightingSwapScorer extends SwapScorer
	{
		SwapScorer parent;
		QueryWeightingSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts);
			this.parent = _parent;
		}
		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i,
				int worseIdx, int rank_j) {
			return queryWeights[queryIndex] * parent.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
		}
		
	}
	
	public QueryWeighting(EvaluationMetric _parent, double[] _queryWeights)
	{
		super(_parent.largerIsBetter());
		this.parent = (RankingEvaluationMetric) _parent;
		this.queryWeights = _queryWeights;
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception {
		return new QueryWeightingSwapScorer(targets, boundaries, trunc, labelCounts, parent.getSwapScorer(targets, boundaries, trunc, labelCounts));
	}

	@Override
	public double[] measureByQuery(double[] predictions, Sample sample)
			throws Exception {
		double[] rtr = parent.measureByQuery(predictions, sample);
		for(int i=0;i<rtr.length;i++)
		{
			rtr[i] *= queryWeights[i];
		}
		return rtr;
	}

}
