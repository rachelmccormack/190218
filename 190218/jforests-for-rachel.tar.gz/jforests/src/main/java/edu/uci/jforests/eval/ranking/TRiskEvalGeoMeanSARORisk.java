package edu.uci.jforests.eval.ranking;

import java.util.Arrays;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.CDF_Normal;
import edu.uci.jforests.util.MathUtil;

public class TRiskEvalGeoMeanSARORisk extends URiskAwareEval {

	public TRiskEvalGeoMeanSARORisk(EvaluationMetric _parent, double alpha) {
		super(_parent, alpha);
	}

	
	class GeoZRiskSwapScorer extends URiskSwapScorer
	{

		public GeoZRiskSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}
		
		@Override
		/* Basic Version */
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double M_m = modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex];
	
			double zrisk_j =  (M_m + M_b) > 0D ? delta_M / Math.sqrt(M_m + M_b) : 0D;
			final double beta = (1 - CDF_Normal.normp(zrisk_j)) * alpha;

			final double delta_T;
			
			//Scenarios are as defined by Wang et al, SIGIR 2012.
			//Scenario A
			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
			if (M_m <=  M_b)
			{
				//case A1
				if (rel_i > rel_j && rank_i < rank_j)
				{
					delta_T = (1.0d + beta) * delta_M;
				}
				//case A2
				else
				{	
					if (M_b > M_m + delta_M)
					{
						delta_T = (1.0d + beta) * delta_M;
					}
					else
					{
						delta_T = beta * (M_b - M_m) + delta_M;
					}					
				}
			}
			else //Scenario B
			{
				if( rel_i > rel_j && rank_i < rank_j )
				{
					//case B1
					if (M_b > M_m - Math.abs(delta_M))
					{
						delta_T = beta * (M_m - M_b) - (1 + beta) * Math.abs(delta_M);
					}
					else
					{
						delta_T = delta_M;
					}
					}
				else 
				{
					delta_T = delta_M;
				}
			}

			return delta_T;
		}

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			if (iteration == 0)
			{
				System.err.println("Iteration 0 NDCG=" + Arrays.toString(nDCG));
			}
			else
			{
				System.err.println("Iteration " + iteration + " NDCG=" + Arrays.toString(nDCG));
			}
		}	
	}

	/** returns double[] params where params[0] = URisk; params[1] = PairedVar. */
	public static double[] getEstimates(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;
        double sum = 0D;
        double zrisk_j = 0D;
        double std = 0D;
        double mean_i = MathUtil.getAvg(perQuery); 
        for(int j=0; j < c; j++)
        {
        	double M_b = baselinePerQuery[j];
            double M_m = perQuery[j];
        	std = M_b + M_m > 0D ? Math.sqrt(M_m + M_b) : 0D;
            zrisk_j = std > 0 ? (M_m - M_b) / std : 0D;
            if (M_b > M_m)
            {
            	double beta = (1 - CDF_Normal.normp(zrisk_j)) * ALPHA;            	
            	zrisk_j = std > 0 ? (1 + beta) * ( (M_m - M_b) / std) : 0D;
            }
            
            sum += zrisk_j;
        }

        final double GeoMean = Math.sqrt(mean_i * CDF_Normal.normp(sum/c));
        return new double[] {GeoMean};
	}
	
	/* Returns GRisk =   */
	public static double GeoMean_measure(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;

        double[] params = getEstimates(baselinePerQuery, perQuery, ALPHA);
		
		return params[0];   
	}
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		final RankingSample rankingSample = (RankingSample)sample;
		assert rankingSample.queryBoundaries.length -1 == rankingSample.numQueries;
		final double[] naturalOrder = computeNaturalOrderScores(predictions.length, rankingSample.queryBoundaries);
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		return GeoMean_measure(baselinePerQuery, perQuery, this.ALPHA);
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new GeoZRiskSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
}
