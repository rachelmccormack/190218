package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.dataset.Dataset;
import edu.uci.jforests.dataset.RankingDataset;
import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.CDF_Normal;
import edu.uci.jforests.util.MathUtil;

public class Geo2ChiSquareEval extends TRiskAwareFAROEval {

	int numQueries;
	double N;
	double[] TF_i;
	double[] D_j;
	String baselinePerformancesTable;
	
	public Geo2ChiSquareEval(EvaluationMetric _parent, double alpha, String baslinePerformancesTable) throws Exception {
		super(_parent, alpha);
		this.baselinePerformancesTable = baslinePerformancesTable;
	}


	@Override
	public void init(Dataset dataset) throws Exception {
		super.init(dataset);
		
		numQueries = ((RankingDataset)dataset).numQueries;
		assert numQueries > 0;
		
		double[][] unNormalisedBaselines = ChiSquareCTIEval.loadSystemPerformancesTable(baselinePerformancesTable);
		final int numSystems = unNormalisedBaselines.length;
		assert unNormalisedBaselines[0].length == numQueries;
		final int numTopics = numQueries;
		//final int numTopics = unNormalisedBaselines[0].length;
		TF_i = new double[numSystems];
		D_j = new double[numTopics];
		
		for(int i=0;i<numSystems;i++)
		{
			double sum = 0d;
			for(int j=0;j<numTopics;j++)
			{
				sum += unNormalisedBaselines[i][j];					
			}
			TF_i[i] = sum; // / (double) numTopics;
			System.err.println("Baseline " + i + " mean = " + TF_i[i] + " over " + numTopics + " topics");
		}
		
		for(int j=0;j<numTopics;j++)		
		{
			double sum = 0d;
			for(int i=0;i<numSystems;i++)
			{
				N += unNormalisedBaselines[i][j];
				sum += unNormalisedBaselines[i][j];
			}
			D_j[j] = sum; // / (double) numSystems;
		}
		System.err.println("Got N="+N+ " from " + numSystems + " baseline systems");
		
		parent.init(dataset);
	}
	
	final double zrisk(final double tf_ij, double e_ij )
    {
        double z_ij = (tf_ij - e_ij) / Math.sqrt(e_ij);
        if (z_ij < 0)
            z_ij = z_ij * (1 + ALPHA);
        return z_ij;
    }

	class ChiSquareSwapScorer extends FAROSwapScorer
	{
		double TF_i;
		double currentGeo;
		double queryCount;
		
		public ChiSquareSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}
		
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			if (iteration == 0)
				modelEval = baselineEval;
			TF_i = MathUtil.getSum(modelEval);
			queryCount = modelEval.length;
			currentGeo = calcGeo(nDCG, 0, 0);
		}
        
        double calcGeo(final double[] nDCG, final int queryIndex, final double delta_M)
        {
        	double Zsum = 0;
			for(int i=0;i<nDCG.length;i++)
			{
				final double Dj = D_j[i];
				final double tf_ij = nDCG[i];
				if (D_j[i] > 0)
				{
					final double e_ij = Dj / N * TF_i;					
					Zsum += zrisk(tf_ij + (queryIndex == i ? delta_M : 0), e_ij);
				}
				else
				{
					Zsum += tf_ij+ (queryIndex == i ? delta_M : 0);
				}
			}
			return Math.pow( (TF_i+delta_M)/queryCount * CDF_Normal.normp(Zsum)/queryCount , 0.5d);
        }
		
		
		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
			
			
			final double rtr = calcGeo(this.modelEval, queryIndex, delta_M) - currentGeo;
			
			
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, rtr);			
			return rtr;
		}
		
		public void assertConsistency(int queryIndex, int betterIdx, int rank_i,
				int worseIdx, int rank_j, double delta_M) {
			
			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
			
			assert ! Double.isNaN(delta_M) : "Delta cannot be NaN! rank_i=" + rank_i + " rank_j="+rank_j + " rel_i=" + rel_i + " rel_j="+ rel_j  ;
			
			//Our LambaMART implementation only calls getDelta when i is of higher quality better than j.
			assert rel_i >= rel_j;
			//the upshot is that not all scenarios in the proof can ever occur. we now check that conditions
			//are as expected
			
			//hence, delta_M should always be zero or positive, if it is later ranked than j. This would be a "good" swap
			if (rank_i > rank_j)
			{
				assert delta_M >= 0 : "improving swap: rank_i=" + rank_i + " rank_j="+rank_j + " rel_i=" + rel_i + " rel_j="+ rel_j + " delta_M="+delta_M;
			}
			//hence, delta_M should always be zero or negative, if it is earlier ranked than j. This would be a "bad" swap
			if (rank_i < rank_j)
			{
				assert delta_M <= 0 : "degrading swap: rank_i=" + rank_i + " rank_j="+rank_j + " rel_i=" + rel_i + " rel_j="+ rel_j +" delta_M="+delta_M;
			}
			
		}
				
	}

	public EvaluationMetric getParentMetric() {
		return parent;
	}
		
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new ChiSquareSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}

	
	public double measureZrisk(double[] predictions, Sample sample) throws Exception 
	{
		
		//this implement Z_risk directly
		double[] parentScores = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		assert parentScores.length == numQueries : "Expected " + numQueries + " queries, received " + parentScores.length;
		double TF_i = MathUtil.getSum(parentScores);
		double sum = 0;
		for(int queryIndex=0;queryIndex<numQueries;queryIndex++)
		{
			final double tf_ij = parentScores[queryIndex];
			if (D_j[queryIndex] > 0)
			{
				final double Dj = D_j[queryIndex];
				
				final double e_ij = Dj / N * TF_i;
				assert e_ij != 0.0d;		
				
                final double z_ij = zrisk(tf_ij, e_ij);
//                
//                (tf_ij - e_ij)/(Math.sqrt(e_ij));
//				
//				if (z_ij > 0)
//					sum += z_ij;
//				else
//					sum += (1.0d+ALPHA) * z_ij;
                sum += z_ij;
			}
			else
			{
				sum +=  tf_ij;
			}
		}
		//AMENDED: 18th January
        final double rtr = Math.sqrt((TF_i/(double)numQueries) * CDF_Normal.normp(sum/(double)numQueries));
		assert ! Double.isNaN(rtr);
		return rtr;
	}
	


	@Override
	public double measure(double[] predictions, Sample sample) throws Exception 
	{
		return measureZrisk(predictions, sample);
		//return measureGsquared_GeoMean(predictions, sample);
	}

	
	public double measureGsquared_GeoMean(double[] predictions, Sample sample) throws Exception 
	{
		double[] parentScores = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		assert parentScores.length == numQueries : "Expected " + numQueries + " queries, received " + parentScores.length;
		double TF_i = MathUtil.getSum(parentScores);
		double sum = 0;
		for(int queryIndex=0;queryIndex<numQueries;queryIndex++)
		{
			if (D_j[queryIndex] > 0)
			{
				final double Dj = D_j[queryIndex];
				final double e_ij = Dj / N * TF_i;
				//assert e_ij != 0.0d;
				final double tf_ij = parentScores[queryIndex];
				sum += Math.pow(tf_ij - e_ij, 2) / e_ij;			
			}
			else
			{
				sum += parentScores[queryIndex];
			}
		}
		final double rtr = sum / (double)numQueries;
		assert ! Double.isNaN(rtr);
		
		double meanEffectiveness = TF_i / (double)numQueries;
		
		return Math.pow(meanEffectiveness/rtr, 0.5d);
	}
	
	
	
	
//	@Override
//	public double measure(double[] predictions, Sample sample) throws Exception 
//	{
//		double[] parentScores = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
//		assert parentScores.length == numQueries : "Expected " + numQueries + " queries, received " + parentScores.length;
//		double TF_i = MathUtil.getSum(parentScores);
//		double sum = 0;
//		for(int queryIndex=0;queryIndex<numQueries;queryIndex++)
//		{
//			if (D_j[queryIndex] > 0)
//			{
//				final double Dj = D_j[queryIndex];
//				final double e_ij = Dj / N * TF_i;
//				assert e_ij != 0.0d;
//				final double tf_ij = parentScores[queryIndex];
//				sum += CDF_Normal.normp( (tf_ij - e_ij) / e_ij );
//			}
//			else
//			{
//				sum += parentScores[queryIndex];
//			}
//		}
//		final double rtr = sum / (double)numQueries;
//		assert ! Double.isNaN(rtr);
//		return rtr;
//	}
	
	@Override
	public double[] measureByQuery(double[] predictions, Sample sample)
			throws Exception 
	{
		throw new RuntimeException("Unsupported");
		/*double[] parentScores = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		assert parentScores.length == numQueries;
		
		double TF_i = MathUtil.getAvg(parentScores) * (double)parentScores.length; 
		
		final double[] rtr = new double[numQueries];
		for(int queryIndex=0;queryIndex<numQueries;queryIndex++)
		{
			if (D_j[queryIndex] > 0)
			{
				final double D_j = getSumOfScoresForTopic(queryIndex);
				final double e_ij = D_j / N * TF_i;	
				final double tf_ij = parentScores[queryIndex];
				rtr[queryIndex] = CDF_Normal.normp( (tf_ij - e_ij) / e_ij );
			}
			else
			{
				rtr[queryIndex] = parentScores[queryIndex];
			}
		}		
		return rtr;
		*/
	}
	
}
