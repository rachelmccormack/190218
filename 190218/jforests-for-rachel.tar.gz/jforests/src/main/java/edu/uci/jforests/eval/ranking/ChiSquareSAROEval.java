package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.util.CDF_Normal;

public class ChiSquareSAROEval extends ChiSquareEval {

	
	class ChiSquareSAROSwapScorer extends ChiSquareSwapScorer
	{
		public ChiSquareSAROSwapScorer(double[] targets, int[] boundaries,
				int trunc, int[][] labelCounts, double _alpha,
				SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}

		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i,
				int worseIdx, int rank_j) {
			//get the change in NDCG
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double tf_ij = modelEval[queryIndex]; // observed score of the model for the current topic, queryIndex

			// Global Params
			// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
			// N is the score sum over all topics and sample runs. It remains constant during training.
			final double Dj = D_j[queryIndex]; // This is the score sum over all baseline runs for the topic. It remains constant during training for each topic.
			double beta = alpha;

			double e_ij;
			if (Dj > 0) { // meaning that the observed score of at least one baseline run is greater than zero. 		
				
				// TF_i is the score sum of the model over all topics. It changes depending on the current iteration.
				assert TF_i != 0.0d;
				
				// Expected score of the model for the topic
				e_ij = Dj / N * TF_i;

				//e_ij cannot be 0
				assert e_ij != 0.0d : "D_j="+Dj + " TF_i="+TF_i + " N="+N;
				
				double chiSquare = (tf_ij - e_ij) / Math.sqrt(e_ij);
				
				beta = (1 - CDF_Normal.normp(chiSquare)) * alpha;
				
			} else {
				//this won't really matter for SARO, as beta is not applied
				
				beta = ( 1 - tf_ij/ 0.1d ) * alpha;
				//expected score is 0
				e_ij = 0;
			}
			
			// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

			double delta_T;
			
			final double M_m = modelEval[queryIndex];
			final double M_b = e_ij;
			
			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
			
			//Scenarios are as defined by Wang et al, SIGIR 2012.
			//Scenario A
			if (M_m <=  M_b)
			{
				//case A1
				if (rel_i > rel_j && rank_i < rank_j)
				{
					delta_T = (1.0d + beta) * delta_M;
				}
				//case A2
				else
				{	
					if (M_b > M_m + delta_M)
					{
						delta_T = (1.0d + beta) * delta_M;
					}
					else
					{
						delta_T = beta * (M_b - M_m) + delta_M;
					}					
				}
			}
			else //Scenario B
			{
				if( rel_i > rel_j && rank_i < rank_j )
				{
					//case B1
					if (M_b > M_m - Math.abs(delta_M))
					{
						delta_T = beta * (M_m - M_b) - (1 + beta) * Math.abs(delta_M);
					}
					else
					{
						delta_T = delta_M;
					}
				}
				else 
				{
					delta_T = delta_M;
				}
			}
			
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, delta_T);
			
			return delta_T;
		}
		
	}

	public ChiSquareSAROEval(EvaluationMetric _parent, double alpha,
			String baselinePerformances) throws Exception {
		super(_parent, alpha, baselinePerformances);
	}


	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new ChiSquareSAROSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
}
