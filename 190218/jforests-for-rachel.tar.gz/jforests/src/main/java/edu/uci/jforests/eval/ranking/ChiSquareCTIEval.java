package edu.uci.jforests.eval.ranking;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.eval.ranking.URiskAwareEval.ParentSwapScorer;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.IOUtils;
import edu.uci.jforests.util.MathUtil;

public class ChiSquareCTIEval extends RankingEvaluationMetric {

	RankingEvaluationMetric parent;
	
	double N = 0d;
	double[] TF_i;
	double[] D_j;
	
	public ChiSquareCTIEval(EvaluationMetric _parent, String[] baslinePerformances) {
		this(_parent, baslinePerformances, 6000); //TODO fix this hack
	}
	
	public ChiSquareCTIEval(EvaluationMetric _parent, String[] baslinePerformances, int numQueries) {
		super(_parent.largerIsBetter());
		parent = (RankingEvaluationMetric) _parent;
		
		try {
			double[][] unNormalised = loadSystemPerformances(baslinePerformances, numQueries);
			final int numSystems = unNormalised.length;
			final int numTopics = unNormalised[0].length;
			TF_i = new double[numSystems];
			D_j = new double[numTopics];
			
			for(int i=0;i<numSystems;i++)
			{
				double sum = 0d;
				for(int j=0;j<numTopics;j++)
				{
					sum += unNormalised[i][j];					
				}
				TF_i[i] = sum; // / (double) numTopics;
				System.err.println("Baseline " + i + " mean = " + TF_i[i] + " over " + numTopics + " topics");
			}
			
			for(int j=0;j<numTopics;j++)		
			{
				double sum = 0d;
				for(int i=0;i<numSystems;i++)
				{
					N += unNormalised[i][j];
					sum += unNormalised[i][j];
				}
				D_j[j] = sum; // / (double) numSystems;
			}
			System.err.println("Got N="+N+ " from " + numSystems + " baseline systems");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static double[][] loadSystemPerformancesTable(
			String baselinePerformancesTable) throws Exception {
		List<List<Double>> table = new ArrayList<List<Double>>();
		BufferedReader br = IOUtils.getReader(baselinePerformancesTable);
		String line = null;
		while((line = br.readLine()) != null)
		{
			List<Double> systemsForThisQuery = new ArrayList<Double>();
			String[] parts = line.split("\\s+");
			for(String p : parts)
			{
				systemsForThisQuery.add(Double.parseDouble(p));
			}
			table.add(systemsForThisQuery);
		}
		final int queryCount = table.size();
		if (queryCount == 0)
			throw new RuntimeException("No rows found in file " + baselinePerformancesTable);
		final int runCount = table.get(0).size();
		final double[][] rtr = new double[runCount][queryCount];
		int query = 0;
		for(List<Double> queryRow : table)
		{
			for (int r=0;r<runCount;r++)
				rtr[r][query] = queryRow.get(r);
			query++;
		}
		return rtr;
	}

	public static double[][] loadSystemPerformances(String files[], int numQueries) throws Exception
	{
		double[][] rtr = new double[files.length][numQueries];
		int system = 0;
		for(String filename : files)
		{
			BufferedReader br =IOUtils.getReader(filename);
			String line = null;
			int query = 0;
			while((line = br.readLine()) != null)
			{
				rtr[system][query++] = Double.parseDouble(line);
			}			
			br.close();	
			system++;
		}		
		return rtr;
	}	
	
	
	final static double SMOOTH = 0.001;
	class ChiSquareCTISwapScorer extends ParentSwapScorer
	{
		
		double thisTF_i; //TF_i for this system
		double queryCount;
		double Gs[];
		double G;
		public ChiSquareCTISwapScorer(double[] targets, int[] boundaries,
				int trunc, int[][] labelCounts, SwapScorer _parent)
		{
			super(targets, boundaries, trunc, labelCounts, _parent);
			Gs = new double[boundaries.length];
		}
		

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			final int numQueries = nDCG.length;
			queryCount = numQueries;			
			
			thisTF_i = MathUtil.getAvg(nDCG) * queryCount;
			double Gsum = 0;
			
			for(int j=0;j<numQueries;j++)
			{
				double eij = thisTF_i * ((D_j[j] + SMOOTH) / (N * (1 + SMOOTH)));
				Gsum += Gs[j] = Math.pow(nDCG[j] - eij,2)/ eij;
				System.err.printf("G+= [(tfij=%f - eij=%f)^2 / eij=%f]=%f\n", nDCG[j], eij, eij,Gs[j]);
			}
			G = Gsum / queryCount;
			System.err.printf("G="+ G + "\n");
		}



		@Override
		public double getDelta(int queryIndex, int betterIdx, int rank_i,
				int worseIdx, int rank_j) 
		{
			final double modelEval = super.modelEval[queryIndex];
			
			//delta, as a proportion of the mean performance
			final double delta = super.parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j) / queryCount;
			
			//triple check NDCG should be consistent
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, delta * queryCount);
			
			final double tfPij = modelEval;
			final double TFPi = thisTF_i + delta;
			final double systemMean = thisTF_i / queryCount;
			
			final double ePij = TFPi * ((D_j[queryIndex] + SMOOTH) / (N * (1 + SMOOTH))); // (D_j[queryIndex] / N);
			assert ePij != 0 : "ePij == 0, where TFPi=" + TFPi + " D_j[j]="+D_j[queryIndex] + "N="+N;
			
			double deltaG = (Math.pow(tfPij - ePij,2)/ ePij ) - Gs[queryIndex];	
			deltaG /= queryCount;
			//System.err.println("deltaG = " + deltaG + " \n");
			
			//return deltaG;
			final double rtr = Math.sqrt((systemMean + delta)/(G + deltaG)) - Math.sqrt(systemMean/G);			
			assert ! Double.isNaN(rtr) : " NaN=sqrt[(NDCG="+systemMean+" + delta="+delta+") / (G="+G+" + deltaG="+deltaG+" )] - sqrt(NDCG="+systemMean+" / G="+G+")";
			//System.err.print( "sqrt[(NDCG="+systemMean+" + delta="+delta+") / (G="+G+" + deltaG="+deltaG+" )] - sqrt(NDCG="+systemMean+" / G="+G+")\n");
			if (rank_i > rank_j)
			{
				assert rtr >= 0 : "improving swap: rank_i=" + rank_i + " rank_j="+rank_j + " rtr="+rtr + "=sqrt[(NDCG="+systemMean+" + delta="+delta+") / (G="+G+" + deltaG="+deltaG+" )] - sqrt(NDCG="+systemMean+" / G="+G+")";;
			}
			else if (rank_i < rank_j)
			{
				assert rtr <= 0 : "degrading swap: rank_i=" + rank_i + " rank_j="+rank_j + " rtr="+rtr + "=sqrt[(NDCG="+systemMean+" + delta="+delta+") / (G="+G+" + deltaG="+deltaG+" )] - sqrt(NDCG="+systemMean+" / G="+G+")";;
			}
			
			//run the consistency assertions
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, rtr);			
			
			return rtr;
		}
	}
	
	public EvaluationMetric getParentMetric() {
		return parent;
	}
	

	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception
	{		
		SwapScorer parentScorer = parent.getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new ChiSquareCTISwapScorer(targets, boundaries, trunc, labelCounts, parentScorer);
	}

	@Override
	public double[] measureByQuery(double[] predictions, Sample sample)
			throws Exception 
	{
		return parent.measureByQuery(predictions, sample);
		//throw new UnsupportedOperationException("Hmmm, not sure how to calculate this one yet");
	}

	
	
}
