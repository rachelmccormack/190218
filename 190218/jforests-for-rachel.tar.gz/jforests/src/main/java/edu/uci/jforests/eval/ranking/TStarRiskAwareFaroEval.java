package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.dataset.Dataset;
import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.util.MathUtil;

public class TStarRiskAwareFaroEval extends TRiskAwareFAROEval {

	
	String baselinePerformancesTable;
	double[] MeanQ_baseline;
	double Mean_MeanQ_baseline;
	
	public TStarRiskAwareFaroEval(EvaluationMetric _parent, double alpha, String baslinePerformancesTable) {
		super(_parent, alpha);
		baselinePerformancesTable = baslinePerformancesTable;
	}
	
	@Override
	public void init(Dataset dataset) throws Exception {
		super.init(dataset);
		
		final double[][] unNormalisedBaselines = ChiSquareCTIEval.loadSystemPerformancesTable(baselinePerformancesTable);
		final int numSystems = unNormalisedBaselines.length;
		final int numTopics = unNormalisedBaselines[0].length;
		
		MeanQ_baseline = new double[numTopics];
		for(int j=0;j<numTopics;j++)		
		{
			double sum = 0d;
			for(int i=0;i<numSystems;i++)
			{
				sum += unNormalisedBaselines[i][j];
			}
			MeanQ_baseline[j] = sum / (double) numSystems;
		}
		Mean_MeanQ_baseline =  MathUtil.getAvg(MeanQ_baseline);
	}

	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new StarFAROSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	

	class StarFAROSwapScorer extends FAROSwapScorer 
	{
		public StarFAROSwapScorer(double[] targets, int[] boundaries,
				int trunc, int[][] labelCounts, double _alpha,
				SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			baselineEval = MeanQ_baseline;
			baselineMean = Mean_MeanQ_baseline;
		}
		
	}
	
}
