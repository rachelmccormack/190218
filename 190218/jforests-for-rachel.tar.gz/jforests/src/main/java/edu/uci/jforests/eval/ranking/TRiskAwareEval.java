package edu.uci.jforests.eval.ranking;

//import static org.junit.Assert.assertEquals;
//import org.junit.Test;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.CDF_Normal;
import edu.uci.jforests.util.MathUtil;
import edu.uci.jforests.util.concurrency.BlockingThreadPoolExecutor;

public class TRiskAwareEval extends URiskAwareEval {

	static final double LOG_2_OF_E = java.lang.Math.log(2.0D);
	static final double REC_LOG_2_OF_E = 1.0D / LOG_2_OF_E;
	
	public TRiskAwareEval(EvaluationMetric _parent, double alpha) {
		super(_parent, alpha);
	}

	static class TRiskSwapScorer extends URiskSwapScorer
	{
		double currPairedSTD = 0.0d;
		double c;
		double baselineMean;
		
		public TRiskSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
			c = ((double) boundaries.length -1);
		}
	

		// VERSION 4: aka phiLog
		@Override
		/* Basic Version */
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double M_m = modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex];

			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
	
			final double ALPHA = alpha;
			
			
			// Old score difference
			double d_i = M_m > M_b ? M_m - M_b : (1 + ALPHA) * (M_m - M_b);

			// New score difference
			final double M_m_new = M_m + delta_M;
			final double d_i_new = M_m_new > M_b ? M_m_new - M_b : (1 + ALPHA) * (M_m_new - M_b);  
			
			final double TRisk_old = d_i / currPairedSTD;
			final double TRisk_new = d_i_new / currPairedSTD;
			
			// Version I: log base 10
//			final double phi_new = Math.log10( 1.0D / CDF_Normal.normp(TRisk_new) );
//			final double phi_old = Math.log10( 1.0D / CDF_Normal.normp(TRisk_old) );
			
			// Version II: log base e
			final double phi_new = Math.log( 1.0D / CDF_Normal.normp(TRisk_new) );
			final double phi_old = Math.log( 1.0D / CDF_Normal.normp(TRisk_old) );
									
			// Version III: log base 2
//			final double phi_old = Math.log( 1.0D / CDF_Normal.normp(TRisk_old) ) * REC_LOG_2_OF_E;
//			final double phi_new = Math.log( 1.0D / CDF_Normal.normp(TRisk_new) ) * REC_LOG_2_OF_E;
			
//			double phi_new = 0, phi_old = 0;
//			if (alpha == 0.0d)
//			{
//				phi_new = Math.log10( 1.0D / CDF_Normal.normp(TRisk_new) );
//				phi_old = Math.log10( 1.0D / CDF_Normal.normp(TRisk_old) );
//			}
//			else if (alpha == 1d)
//			{
//				phi_new = Math.log( 1.0D / CDF_Normal.normp(TRisk_new) );
//				phi_old = Math.log( 1.0D / CDF_Normal.normp(TRisk_old) );
//			}
//			else if (alpha == 5d)
//			{
//				phi_new = Math.log( 1.0D / CDF_Normal.normp(TRisk_new) ) * REC_LOG_2_OF_E;
//				phi_old = Math.log( 1.0D / CDF_Normal.normp(TRisk_old) ) * REC_LOG_2_OF_E;
//			}
				
			
			final double delta_T ;//= phi_old - phi_new;
			//Scenario A
			if (M_m <=  M_b)
			{
				//case A1
				if (rel_i > rel_j && rank_i < rank_j)
				{
					delta_T = phi_old - phi_new;
				}
				//case A2
				else
				{	
					if (M_b > M_m + delta_M)
					{
						delta_T = phi_old - phi_new;
					}
					else
					{
						//delta_T = alpha * (M_b - M_m) + delta_M;
						delta_T = phi_old - phi_new;
					}					
				}
			}
			else //Scenario B
			{
				if( rel_i > rel_j && rank_i < rank_j )
				{
					//case B1
					if (M_b > M_m - Math.abs(delta_M))
					{
						//delta_T = alpha * (M_m - M_b) - (1 + alpha) * Math.abs(delta_M);
						delta_T = phi_old - phi_new;
					}
					else
					{
						delta_T = delta_M;
					}
				}
				else 
				{
					delta_T = delta_M;
				}
			}
			//System.err.println("parentSwapDelta="+parentSwapDelta + " newT_risk="+newT_risk+" oldT_risk="+oldT_risk+" delta_T="+delta_T);
			
			//now makes some checks that the consistency property holds: 
			
			//we know the following should always hold, as per URisk implementation
			//assert rel_i >= rel_j;
			//hence, delta_M should always be zero or positive, if it is later ranked than j. This would be a "good" swap
			if (rank_i > rank_j)
			{
				assert delta_M >= 0 : "rank_i=" + rank_i + " rank_j="+rank_j + " delta_M="+delta_M;
				assert delta_T >= 0 : " delta_M=" + delta_M + " delta_T="+delta_T 
						+" oldT_risk="+TRisk_old + " newT_risk="+TRisk_new + " d_i_new="+d_i_new+ " d_i_old="+d_i;
			}
			//hence, delta_M should always be zero or negative, if it is earlier ranked than j. This would be a "bad" swap
			if (rank_i < rank_j)
			{
				assert delta_M <= 0 : "rank_i=" + rank_i + " rank_j="+rank_j + " delta_M="+delta_M;
				assert delta_T <= 0 : " delta_M=" + delta_M + " delta_T="+delta_T
						+" oldT_risk="+TRisk_old + " newT_risk="+TRisk_new + " d_i_new="+d_i_new+ " d_i_old="+d_i;
			}

			return delta_T;
		}
		
//		//TRiskAwareEvalBTD3
//		@Override
//		/* Basic Version */
//		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
//		{
//			//get the change in NDCG
//			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
//
//			final double M_m = modelEval[queryIndex];
//			final double M_b = baselineEval[queryIndex];
//
//			// Score difference
//			double d_i = M_m - M_b;
//
//			final double TRisk = d_i / currPairedSTD;
//			
//			// beta asymptotically ranges in between a value as small as 0 and a value as large as alpha,
//			// proportionally to the level of risk commited by the current topic.
//			// This version follows its own way of weighing a given delta.
//			final double beta = (1 - CDF_Normal.normp(TRisk)) * alpha;
//
//			final double delta_T = (1 + beta) * delta_M;
//			
//			
//			//now makes some checks that the consistency property holds: 
//			
//			//we know the following should always hold, as per URisk implementation
//			//assert rel_i >= rel_j;
//			//hence, delta_M should always be zero or positive, if it is later ranked than j. This would be a "good" swap
//			if (rank_i > rank_j)
//			{
//				assert delta_M >= 0 : "rank_i=" + rank_i + " rank_j="+rank_j + " delta_M="+delta_M;
//				assert delta_T >= 0 : " delta_M=" + delta_M + " delta_T="+delta_T 
//						;
//			}
//			//hence, delta_M should always be zero or negative, if it is earlier ranked than j. This would be a "bad" swap
//			if (rank_i < rank_j)
//			{
//				assert delta_M <= 0 : "rank_i=" + rank_i + " rank_j="+rank_j + " delta_M="+delta_M;
//				assert delta_T <= 0 : " delta_M=" + delta_M + " delta_T="+delta_T
//					;
//			}
//			
//			return delta_T;
//		}
		
		//TRiskAwareEvalBTD2
//		@Override
//		/* Basic Version */
//		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
//		{
//			//get the change in NDCG
//			final double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);
//
//			final double M_m = modelEval[queryIndex];
//			final double M_b = baselineEval[queryIndex];
//
//			// Score difference
//			double d_i = M_m - M_b;
//
//			final double TRisk = d_i / currPairedSTD;
//			
//			// beta asymptotically ranges in between a value as small as 0 and a value as large as alpha,
//			// proportionally to the level of risk commited by the current topic.
//			// This version follows the way how URisk weighs a given delta.
//			final double beta = (1 - CDF_Normal.normp(TRisk)) * alpha;
//
//			final double delta_T;
//			
//			final double rel_i = targets[betterIdx];
//			final double rel_j = targets[worseIdx];
//			
//			//Scenario A
//			if (M_m <=  M_b)
//			{
//				//case A1
//				if (rel_i > rel_j && rank_i < rank_j)
//				{
//					delta_T = (1.0d + beta) * delta_M;
//				}
//				//case A2
//				else
//				{	
//					if (M_b > M_m + delta_M)
//					{
//						delta_T = (1.0d + beta) * delta_M;
//					}
//					else
//					{
//						delta_T = beta * (M_b - M_m) + delta_M;
//					}					
//				}
//			}
//			else //Scenario B
//			{
//				if( rel_i > rel_j && rank_i < rank_j )
//				{
//					//case B1
//					if (M_b > M_m - Math.abs(delta_M))
//					{
//						delta_T = beta * (M_m - M_b) - (1 + beta) * Math.abs(delta_M);
//					}
//					else
//					{
//						delta_T = delta_M;
//					}
//				}
//				else 
//				{
//					delta_T = delta_M;
//				}
//			}
//
//			return delta_T;
//		}

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
			if (iteration == 0)
			{
		        double[] params = getEstimates(baselineEval, modelEval, this.alpha);
				currPairedSTD = Math.sqrt(params[1]);
				System.err.println("Iteration 0 Paired STD="+ currPairedSTD);
				baselineMean = MathUtil.getAvg(baselineEval);
				System.err.println("Iteration 0 NDCG=" + Arrays.toString(nDCG));
			}
			else
			{
				final double modelMean = MathUtil.getAvg(nDCG);
				if (modelMean < baselineMean)
				{
			        double[] params = getEstimates(baselineEval, modelEval, this.alpha);
					currPairedSTD = Math.sqrt(params[1]);	
					System.err.println("Iteration " + iteration + " Paired STD=" + currPairedSTD);
				}
				else
				{
					System.err.println("Iteration " + iteration + " Paired STD unchanged " + currPairedSTD);
				}
				System.err.println("Iteration " + iteration + " NDCG=" + Arrays.toString(nDCG));
			}
		}	
	}
	
	/* Returns new double[] = {URisk, PairedVar} */
	public static double[] getEstimates(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;
        double sum = 0D;
        double SSQR = 0D;
        double d_i = 0D;

        for(int i=0; i < c; i++)
        {
            if (perQuery[i] > baselinePerQuery[i])
                d_i = perQuery[i] - baselinePerQuery[i];
            else
                d_i = (1 + ALPHA) * (perQuery[i] - baselinePerQuery[i]);
            sum += d_i;
            SSQR += d_i * d_i;
        }

        final double URisk = sum /c;
        final double SQRS = sum * sum; 
        final double pairedVar = SSQR == SQRS ? 0 : ( SSQR - (SQRS / c) ) / (c-1);
        return new double[] {URisk, pairedVar};
	}
	
	
	/* Returns TRisk =  Math.sqrt(c / PairedVar) * URisk */
	public static double T_measure(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;

        double[] params = getEstimates(baselinePerQuery, perQuery, ALPHA);
		
		return params[1] == 0D ? 0 : Math.sqrt(c / params[1]) * params[0];   
	}

	
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		final RankingSample rankingSample = (RankingSample)sample;
		assert rankingSample.queryBoundaries.length -1 == rankingSample.numQueries;
		final double[] naturalOrder = computeNaturalOrderScores(predictions.length, rankingSample.queryBoundaries);
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		return T_measure(baselinePerQuery, perQuery, this.ALPHA);
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new TRiskSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
	public static class TestTRiskSwaps 
	{
		@Test public void testTwoOrThreeQueries() throws Exception
		{
			BlockingThreadPoolExecutor.init(1);
			TRiskAwareEval eval = new TRiskAwareEval(new NDCGEval(2,  2), 1);
			SwapScorer s;
			
			s = eval.getSwapScorer(
					new double[]{0,1,0,1}, 
					new int[]{0,2,4}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1,0.2});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			s = eval.getSwapScorer(
					new double[]{0,1,0,1,0,1}, 
					new int[]{0,2,4,6}, 
					2, 
					new int[][]{new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}, new int[]{1,1,0,0,0}});
			s.setCurrentIterationEvaluation(0, new double[]{0.1,0.2,0.1});
			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			
//			s = eval.getSwapScorer(
//					new double[]{0,1}, 
//					new int[]{0,2}, 
//					2, 
//					new int[][]{new int[]{1,1,0,0,0}});
//			s.setCurrentIterationEvaluation(0, new double[]{0.2});
//			System.err.println(s.getDelta(0, 0, 0, 1, 1));
			
			assertTrue(true);
		}
	}
}
