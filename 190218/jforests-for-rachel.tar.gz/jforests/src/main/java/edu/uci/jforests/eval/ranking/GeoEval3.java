package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.util.MathUtil;

public class GeoEval3 extends GeoEval {

	public GeoEval3(EvaluationMetric _parent)
	{
		super(_parent);
	}
	
	static class GeoSwapScorer3 extends GeoEval.GeoSwapScorer
	{
		GeoSwapScorer3(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, SwapScorer _parentSwap) throws Exception {
			super(targets, boundaries, trunc, labelCounts, _parentSwap);
		}
		
		@Override
		public final double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j)
		{			
			assert betterIdx < labels.length;
			assert worseIdx < labels.length;
			
			final double queryMaxDcg = maxDCG[queryIndex];
			
			double delta = (NDCGEval.GAINS[labels[betterIdx]] - NDCGEval.GAINS[labels[worseIdx]])
							* ((NDCGEval.discounts[rank_j] - NDCGEval.discounts[rank_i])) / queryMaxDcg;

			// Version 1
			//double M_m = modelEval[queryIndex] < M_SMALLEST ? M_SMALLEST : modelEval[queryIndex];
			//delta = Math.log(M_m + delta) - Math.log(M_m); // i.e. percent change in per-query model effectiveness. 
			
			// Version 2
			//double M_m = modelEval[queryIndex];
			//delta = MathUtil.log2(M_m + delta + 1) - MathUtil.log2(M_m + 1); // i.e. percent change in per-query model effectiveness with zero-score correction. 

			// Version 3
			double M_m = modelEval[queryIndex];
			delta = MathUtil.log2(M_m + delta + 0.2) - MathUtil.log2(M_m + 0.2); // i.e. percent change in per-query model effectiveness with zero-score correction. 
			
			return delta;
		}
		
	}
	

	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception {
		final SwapScorer parentScorer = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new GeoSwapScorer3(targets, boundaries, trunc, labelCounts, parentScorer);
	}
	
}
