/**
  * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package edu.uci.jforests.applications;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.uci.jforests.config.RankingTrainingConfig;
import edu.uci.jforests.dataset.Dataset;
import edu.uci.jforests.dataset.RankingDataset;
import edu.uci.jforests.dataset.RankingDatasetLoader;
import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.eval.ranking.ChiSquareCTIEval;
import edu.uci.jforests.eval.ranking.ChiSquareEval;
import edu.uci.jforests.eval.ranking.ChiSquareSAROEval;
import edu.uci.jforests.eval.ranking.GOFEval;
import edu.uci.jforests.eval.ranking.GOFFAROEval;
import edu.uci.jforests.eval.ranking.GOFSAROEval;
import edu.uci.jforests.eval.ranking.Geo3ChiSquareEval;
import edu.uci.jforests.eval.ranking.GeoEval;
import edu.uci.jforests.eval.ranking.GeoEval2;
import edu.uci.jforests.eval.ranking.GeoEval3;
import edu.uci.jforests.eval.ranking.MAPEval;
import edu.uci.jforests.eval.ranking.NDCGEval;
import edu.uci.jforests.eval.ranking.TRiskAwareFAROEval;
import edu.uci.jforests.eval.ranking.TRiskAwareSAROEval;
import edu.uci.jforests.eval.ranking.TRiskEvalGeoMeanSARORisk;
import edu.uci.jforests.eval.ranking.TStarRiskAwareFaroEval;
import edu.uci.jforests.eval.ranking.URiskAwareEval;
import edu.uci.jforests.eval.ranking.URiskRatioEval;
import edu.uci.jforests.input.RankingRaw2BinConvertor;
import edu.uci.jforests.input.Raw2BinConvertor;
import edu.uci.jforests.learning.LearningModule;
import edu.uci.jforests.learning.boosting.LambdaMART;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;
import edu.uci.jforests.util.Util;

/**
 * @author Yasser Ganjisaffar <ganjisaffar at gmail dot com>
 */

public class RankingApp extends ClassificationApp {

	protected int maxDocsPerQuery;

	public RankingApp() {
		super();
	}

	@Override
	protected void init() throws Exception {
		maxDocsPerQuery = ((RankingDataset) trainSet.dataset).maxDocsPerQuery;
		if (validSet != null) {
			maxDocsPerQuery = Math.max(maxDocsPerQuery, ((RankingDataset) validSet.dataset).maxDocsPerQuery);
		}
		NDCGEval.initialize(maxDocsPerQuery);
		super.init();

		String trainQidsFilename = ((RankingTrainingConfig) trainingConfig).trainQidsFilename;
		if (trainQidsFilename != null) {
			List<Integer> trainQids = Util.loadIntegersFromFile(trainQidsFilename);
			List<Integer> validQids = new ArrayList<Integer>();
			int validSize = (int) (trainQids.size() * 0.4);
			for (int i = 0; i < validSize; i++) {
				int idx = rnd.nextInt(trainQids.size());
				int qid = trainQids.get(idx);
				trainQids.remove(idx);
				validQids.add(qid);
			}
			Collections.sort(validQids);
			RankingSample newTrainSet = ((RankingSample) trainSet).getFilteredSubSample(trainQids);
			validSet = ((RankingSample) trainSet).getFilteredSubSample(validQids);
			trainSet = newTrainSet;
		}
	}

	@Override
	protected void loadConfig() {
		trainingConfig = new RankingTrainingConfig();
		trainingConfig.init(configHolder);
	}

	@Override
	protected Dataset newDataset() {
		return new RankingDataset();
	}

	@Override
	public void initDataset(Dataset dataset) throws Exception {
		if (dataset == null || !dataset.needsInitialization) {
			return;
		}
		RankingDataset rankingDataset = (RankingDataset) dataset;
		int[][] labelCounts = NDCGEval.getLabelCountsForQueries(rankingDataset.targets, rankingDataset.queryBoundaries);
		rankingDataset.maxDCG = NDCGEval.getMaxDCGForAllQueriesUptoTruncation(rankingDataset.targets, rankingDataset.queryBoundaries,
				NDCGEval.MAX_TRUNCATION_LEVEL, labelCounts);
	}

	@Override
	public void loadDataset(InputStream in, Dataset dataset) throws Exception {
		RankingDatasetLoader.load(in, (RankingDataset) dataset);
	}

	@Override
	protected LearningModule getLearningModule(String name) throws Exception {
		int maxTrainInstances = getMaxTrainInstances();		
		if (name.equals("LambdaMART")) {
			LambdaMART learner = new LambdaMART();
			learner.init(configHolder, (RankingDataset) trainDataset, maxTrainInstances, (validDataset != null ? validDataset.numInstances
					: trainDataset.numInstances), trainMetric, validMetric);
			return learner;
		}
		else {
			return super.getLearningModule(name);
		}
	}

	@Override
	protected EvaluationMetric getEvaluationMetric(String name, EvaluationPhase when) throws Exception {
		System.err.println(name);
		
		if (name.startsWith("ChiSquareEval:"))
		{
			final String[] parts = name.split(":");
			final String baselineTableFile = parts[1];
			final double ALPHA = Double.parseDouble(parts[2]);
			final String parentMeasure = parts[3];
			return new ChiSquareEval(this.getEvaluationMetric(parentMeasure, when), ALPHA, baselineTableFile);			
		}
		if (name.startsWith("ChiSquareSAROEval:"))
		{
			final String[] parts = name.split(":");
			final String baselineTableFile = parts[1];
			final double ALPHA = Double.parseDouble(parts[2]);
			final String parentMeasure = parts[3];
			return new ChiSquareSAROEval(this.getEvaluationMetric(parentMeasure, when), ALPHA, baselineTableFile);			
		}
        if (name.startsWith("GeoChiSquareEval:"))
        {
            final String[] parts = name.split(":");
            final String baselineTableFile = parts[1];
            final double ALPHA = Double.parseDouble(parts[2]);
            final String parentMeasure = parts[3];
            return new Geo3ChiSquareEval(this.getEvaluationMetric(parentMeasure, when), ALPHA, baselineTableFile);
        }
        if (name.startsWith("TStarRiskAwareFaroEval:"))
        {
            final String[] parts = name.split(":");
            final String baselineTableFile = parts[1];
            final double ALPHA = Double.parseDouble(parts[2]);
            final String parentMeasure = parts[3];
            return new TStarRiskAwareFaroEval(this.getEvaluationMetric(parentMeasure, when), ALPHA, baselineTableFile);
        }
		if (name.startsWith("ChiSquareCTIEval:"))
		{
			final String[] parts = name.split(":");
			final String parentMeasure = parts[1];
			String[] baselines = configHolder.getStringProperty("ChiSquareCTIEval.baselines").split(",");
			return new ChiSquareCTIEval(this.getEvaluationMetric(parentMeasure, when), baselines);			
		}
		if (name.startsWith("URiskRatioEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new URiskRatioEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("GOFEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new GOFEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("GOFSAROEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new GOFSAROEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("GOFFAROEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new GOFFAROEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("GeoEval:"))
		{
			final String[] parts = name.split(":");
			final String parentMeasure = parts[1];
			return new GeoEval(this.getEvaluationMetric(parentMeasure, when));			
		}
		if (name.startsWith("GeoEval2:"))
		{
			final String[] parts = name.split(":");
			final String parentMeasure = parts[1];
			return new GeoEval2(this.getEvaluationMetric(parentMeasure, when));			
		}
		if (name.startsWith("GeoEval3:"))
		{
			final String[] parts = name.split(":");
			final String parentMeasure = parts[1];
			return new GeoEval3(this.getEvaluationMetric(parentMeasure, when));			
		}
		if (name.startsWith("URiskAwareEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new URiskAwareEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("TRiskAwareEvalSARO:") || name.startsWith("TRiskAwareSAROEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new TRiskAwareSAROEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("TRiskAwareEvalFARO:")|| name.startsWith("TRiskAwareFAROEval:"))
		{
			final String[] parts = name.split(":");
			final double ALPHA = Double.parseDouble(parts[1]);
			final String parentMeasure = parts[2];
			return new TRiskAwareFAROEval(this.getEvaluationMetric(parentMeasure, when), ALPHA);			
		}
		if (name.startsWith("TRiskEvalGeoMeanSARORisk"))
		{
			final String[] parts = name.split(":");
            final double ALPHA = Double.parseDouble(parts[1]);
            final String parentMeasure = parts[2];
            return new TRiskEvalGeoMeanSARORisk(this.getEvaluationMetric(parentMeasure, when), ALPHA);
		}
		if (name.equals("NDCG")) {
			return new NDCGEval(maxDocsPerQuery, 
				when == EvaluationPhase.TRAINING
					? ((RankingTrainingConfig) trainingConfig).trainNDCGTruncation
					: ((RankingTrainingConfig) trainingConfig).validNDCGTruncation);
		}
		if (name.equals("MAP")) {
			return new MAPEval(maxDocsPerQuery);
		}
		
		return super.getEvaluationMetric(name, when);
	}

	@Override
	protected Sample createSample(Dataset dataset, boolean trainSample) {
		RankingSample sample = new RankingSample((RankingDataset) dataset);
		RankingTrainingConfig config = (RankingTrainingConfig) trainingConfig;
		if (trainSample) {
			if (config.augmentationDocSamplingEnabled) {
				return sample.getAugmentedSampleWithDocSampling(config.augmentationDocSamplingTimes, config.augmentationDocSamplingRate, rnd);
			}
		}
		return sample;
	}

	@Override
	protected int getMaxTrainInstances() {
		RankingTrainingConfig config = (RankingTrainingConfig) trainingConfig;
		if (config.augmentationDocSamplingEnabled) {
			return trainDataset.numInstances * (config.augmentationDocSamplingTimes + 1);
		} else {
			return trainDataset.numInstances;
		}
	}
	
	@Override public Raw2BinConvertor getConvertor()
	{
		return new RankingRaw2BinConvertor();
	}

}
