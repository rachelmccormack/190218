package edu.uci.jforests.eval.ranking;

import edu.uci.jforests.eval.EvaluationMetric;
import edu.uci.jforests.sample.RankingSample;
import edu.uci.jforests.sample.Sample;

/**
 * Chi-Square Goodness of Fit test as a measure of Risk.
 * @author dtaner
 *
 */

public class GOFEval extends URiskAwareEval {

	static boolean DEBUG = false;
	
	public GOFEval(EvaluationMetric _parent, double alpha) {
		super(_parent, alpha);
	}

	class GOFSwapScorer extends URiskSwapScorer
	{

		public GOFSwapScorer(double[] targets, int[] boundaries, int trunc,
				int[][] labelCounts, double _alpha, SwapScorer _parent) {
			super(targets, boundaries, trunc, labelCounts, _alpha, _parent);
		}
		
		@Override
		/* Basic Version */
		public double getDelta(int queryIndex, int betterIdx, int rank_i, int worseIdx, int rank_j) 
		{
			//get the change in NDCG
			double delta_M = parentSwap.getDelta(queryIndex, betterIdx, rank_i, worseIdx, rank_j);

			final double M_m = modelEval[queryIndex];
			final double M_b = baselineEval[queryIndex];
			final double rel_i = targets[betterIdx];
			final double rel_j = targets[worseIdx];
	
			double delta_M_orig = delta_M;
			delta_M = (M_m + M_b) !=0 ? delta_M / Math.sqrt(M_m + M_b) : delta_M;

			final double beta = alpha;

			final double delta_T;
			
			//Scenarios are as defined by Wang et al, SIGIR 2012.
			//Scenario A
			if (M_m <=  M_b)
			{
				//case A1
				if (rel_i > rel_j && rank_i < rank_j)
				{
					delta_T = (1.0d + beta) * delta_M;
				}
				//case A2
				else
				{	
					if (M_b > M_m + delta_M)
					{
						delta_T = (1.0d + beta) * delta_M;
					}
					else
					{
						delta_T = beta * (M_b - M_m) + delta_M;
					}					
				}
			}
			else //Scenario B
			{
				if( rel_i > rel_j && rank_i < rank_j )
				{
					//case B1
					if (M_b > M_m - Math.abs(delta_M))
					{
						delta_T = beta * (M_m - M_b) - (1 + beta) * Math.abs(delta_M);
					}
					else
					{
						delta_T = delta_M;
					}
					}
				else 
				{
					delta_T = delta_M;
				}
			}
			if (DEBUG && iter < 3)
				System.err.println("query="+queryIndex+" rank_i="+rank_i+" rank_j="+rank_j + " rel_i="+rel_i + " rel_j="+rel_j+" M_b="+ M_b + "M_m="+M_m+ " delta_M_orig="+delta_M_orig+" delta_M="+delta_M +" delta_T="+delta_T);
			assertConsistency(queryIndex, betterIdx, rank_i, worseIdx, rank_j, delta_T);
			
			return delta_T;
		}
		
		int iter = 0;

		@Override
		public void setCurrentIterationEvaluation(int iteration, double[] nDCG) {
			super.setCurrentIterationEvaluation(iteration, nDCG);
//			if (iteration == 0)
//			{
//				System.err.println("Iteration 0 NDCG=" + java.util.Arrays.toString(nDCG));
//			}
//			else
//			{
//				System.err.println("Iteration " + iteration + " NDCG=" + java.util.Arrays.toString(nDCG));
//			}
			iter = iteration;
		}	
	}

	/** returns double[] params where params[0] = URisk; params[1] = PairedVar. */
	public static double[] getEstimates(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;
        double sum = 0D;
        double d_i = 0D;
        double std = 0D;
        
        for(int i=0; i < c; i++)
        {
        	std = perQuery[i] + baselinePerQuery[i];
            if (perQuery[i] > baselinePerQuery[i])
                d_i = std > 0 ? (perQuery[i] - baselinePerQuery[i]) / std : 0D;
            else
                d_i = std > 0 ? (1 + ALPHA) * ( (perQuery[i] - baselinePerQuery[i]) / std) : 0D;
            sum += d_i;
        }

        final double GRisk = sum;
        return new double[] {GRisk};
	}
	
	/* Returns GRisk =   */
	public static double G_measure(final double[] baselinePerQuery, final double[] perQuery, final double ALPHA)
	{
        final double c = baselinePerQuery.length;

        double[] params = getEstimates(baselinePerQuery, perQuery, ALPHA);
		
		return params[0] / c;   
	}
	
	@Override
	public double measure(double[] predictions, Sample sample) throws Exception {
		
		final RankingSample rankingSample = (RankingSample)sample;
		assert rankingSample.queryBoundaries.length -1 == rankingSample.numQueries;
		final double[] naturalOrder = computeNaturalOrderScores(predictions.length, rankingSample.queryBoundaries);
				
		double[] baselinePerQuery = ((RankingEvaluationMetric) parent).measureByQuery(naturalOrder, sample);
		double[] perQuery = ((RankingEvaluationMetric) parent).measureByQuery(predictions, sample);
		return G_measure(baselinePerQuery, perQuery, this.ALPHA);
	}
	
	@Override
	public SwapScorer getSwapScorer(double[] targets, int[] boundaries,
			int trunc, int[][] labelCounts) throws Exception 
	{
		final SwapScorer parentMeasure = ((RankingEvaluationMetric) parent).getSwapScorer(targets, boundaries, trunc, labelCounts);
		return new GOFSwapScorer(targets, boundaries, trunc, labelCounts,
				ALPHA, 
				parentMeasure);
	}
	
}
